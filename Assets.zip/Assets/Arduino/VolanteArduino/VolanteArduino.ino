// Volante + 2 pedales (potenciómetros) + 2 botones
// Envía valores crudos: acelerador,volante,freno,ciclar,atras
// Ej: 300,512,718,0,0

const int PIN_ACELERAR = A1;   // Pedal acelerador
const int PIN_VOLANTE  = A0;   // Volante
const int PIN_FRENO    = A2;   // Pedal freno
const int PIN_CICLAR   = 4;    // Botón entre pin 4 y GND
const int PIN_ATRAS    = 5;    // Botón entre pin 5 y GND

void setup() {
  Serial.begin(9600);
  pinMode(PIN_CICLAR, INPUT_PULLUP);
  pinMode(PIN_ATRAS, INPUT_PULLUP);
}

void loop() {
  int acelerar = analogRead(PIN_ACELERAR);
  int volante  = analogRead(PIN_VOLANTE);
  int freno    = analogRead(PIN_FRENO);
  int ciclar   = !digitalRead(PIN_CICLAR);   // presionado = 1
  int atras    = !digitalRead(PIN_ATRAS);

  Serial.print(acelerar); Serial.print(",");
  Serial.print(volante);  Serial.print(",");
  Serial.print(freno);    Serial.print(",");
  Serial.print(ciclar);   Serial.print(",");
  Serial.println(atras);

  delay(30);
}